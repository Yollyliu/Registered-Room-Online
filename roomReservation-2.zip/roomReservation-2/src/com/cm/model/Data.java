package com.cm.model;

import com.cm.dao.Dao;

import java.util.ArrayList;
import java.util.HashMap;

public class Data {
    public static ArrayList<Reservation> reservations;
    public static ArrayList<Room> rooms;
    public static ArrayList<User> users;
    public static Dao dao = new Dao();

    public Data(){
        users = dao.getUser();
    }

    public void getData(){
        rooms = dao.getRooms();
        reservations = dao.getReservation();
    }

    public void setData(){
        dao.updateReservation(reservations);
        dao.updateRoom(rooms);
    }
}

