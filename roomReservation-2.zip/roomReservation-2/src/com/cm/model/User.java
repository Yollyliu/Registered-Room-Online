package com.cm.model;

public class User {
    public String id;
    public String password;
    public int authority;

    public User(){

    }

}
