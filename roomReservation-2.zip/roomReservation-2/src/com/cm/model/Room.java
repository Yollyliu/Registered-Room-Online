package com.cm.model;

import java.util.ArrayList;
import java.util.HashMap;

public class Room {
    public String rid;
    public String date;
    public String name;
    public String timeslot;
    public int capacity;
    public String kind;
    public boolean reserved;

    public Room(){

    }
}
