package com.cm.model;

public class Reservation {

    public String id;
    public String rid;

    @Override
    public boolean equals(Object obj) {
        Reservation reservation = (Reservation) obj;
        return reservation.id.equals(id) && reservation.rid.equals(rid);
    }
}
