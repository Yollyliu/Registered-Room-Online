package com.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;
import com.cm.utils.ConnectionManager;



public class Dao {

    private Connection connection;

    public Dao() {
        connection = ConnectionManager.getConnection();
    }

    public void updateReservation(ArrayList<Reservation> reservation) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("TRUNCATE TABLE reservation");
            preparedStatement.executeUpdate();
            for (Reservation r : reservation) {
                preparedStatement = connection
                        .prepareStatement("insert into reservation(id,rid) values (?, ?)");
                // Parameters start with 1
                preparedStatement.setString(1, r.id);
                preparedStatement.setString(2, r.rid);
                preparedStatement.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Reservation> getReservation() {
        ArrayList<Reservation> reservations = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from reservation");
            // Parameters start with 1
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Reservation reservation = new Reservation();
                reservation.id = rs.getString("id");
                reservation.rid = rs.getString("rid");
                reservations.add(reservation);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservations;
    }

    public void updateRoom(ArrayList<Room> rooms) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("TRUNCATE TABLE room");
            preparedStatement.executeUpdate();
            for (Room r : rooms) {
                preparedStatement = connection
                        .prepareStatement("insert into room(rid, date, name, timeslot, kind, capacity, reserved) values (?, ?,?,?,?,?,?)");
                // Parameters start with 1
                preparedStatement.setString(1, r.rid);
                preparedStatement.setString(2, r.date);
                preparedStatement.setString(3, r.name);
                preparedStatement.setString(4, r.timeslot);
                preparedStatement.setString(5, r.kind);
                preparedStatement.setInt(6, r.capacity);
                preparedStatement.setBoolean(7, r.reserved);

                preparedStatement.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Room> getRooms() {
        ArrayList<Room> rooms = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from room");
            // Parameters start with 1
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.rid = rs.getString("rid");
                room.date = rs.getString("date");
                room.kind = rs.getString("kind");
                room.timeslot = rs.getString("timeslot");
                room.name = rs.getString("name");
                room.capacity = rs.getInt("capacity");
                room.reserved = rs.getBoolean("reserved");
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public ArrayList<User> getUser() {
        ArrayList<User> users = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from user");
            // Parameters start with 1
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.id = rs.getString("id");
                user.password = rs.getString("pwd");
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }


}