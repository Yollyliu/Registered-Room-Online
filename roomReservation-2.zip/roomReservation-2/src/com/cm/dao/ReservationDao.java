package com.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.cm.model.Reservation;

import com.cm.utils.ConnectionManager;

public class ReservationDao {

    private Connection connection;

    public ReservationDao() {
        connection = ConnectionManager.getConnection();
    }

    public int getReservationNumber(String id){
        int i=0;
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from reservation where id=?");
            // Parameters start with 1
            preparedStatement.setString(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    public void addReservation(Reservation reservation) {
        try {
//            System.out.println(reservation.id);
//            System.out.println(reservation.rid);
            PreparedStatement preparedStatement = connection
                        .prepareStatement("insert into reservation(id,rid) values (?, ?)");
                // Parameters start with 1
                preparedStatement.setString(1, reservation.id);
                preparedStatement.setString(2, reservation.rid);
                preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteReservation(Reservation reservation) {
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("delete from reservation where rid=?");

            preparedStatement.setString(1, reservation.rid);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



}