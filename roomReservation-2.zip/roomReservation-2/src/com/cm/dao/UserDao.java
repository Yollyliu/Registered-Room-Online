package com.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;
import com.cm.utils.ConnectionManager;

public class UserDao {

    private Connection connection;

    public UserDao() {
        connection = ConnectionManager.getConnection();
    }

    public void createUser(User user){
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("insert into user VALUES (?, ?, ?)");
            // Parameters start with 1
            preparedStatement.setString(1, user.id);
            preparedStatement.setString(2, user.password);
            preparedStatement.setInt(3, user.authority);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public User getUser(String id, String password) {
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from user where binary id=? and binary pwd = ?");
            // Parameters start with 1
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, password);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                User user = new User();
                user.id = rs.getString("id");
                user.password = rs.getString("pwd");
                user.authority = rs.getInt("authority");
                return user;
            }else{
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User getUserById(String id) {
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from user where id=?");
            // Parameters start with 1
            preparedStatement.setString(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                User user = new User();
                user.id = rs.getString("id");
                user.password = rs.getString("pwd");
                user.authority = rs.getInt("authority");
                return user;
            }else{
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}