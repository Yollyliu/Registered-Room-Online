package com.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;
import com.cm.utils.ConnectionManager;

public class RoomDao {

    private Connection connection;

    public RoomDao() {
        connection = ConnectionManager.getConnection();
    }

    public void createRoom(Room room){
        try {
            PreparedStatement preparedStatement;


            preparedStatement = connection
                    .prepareStatement("insert into room VALUES (?, ?, ?, ?, ?, ?, ?)");
            // Parameters start with 1
            preparedStatement.setString(1, room.rid);
            preparedStatement.setString(2, room.date);
            preparedStatement.setString(3, room.name);
            preparedStatement.setString(4, room.timeslot);
            preparedStatement.setString(5, room.kind);
            preparedStatement.setInt(6, room.capacity);
            preparedStatement.setBoolean(7, room.reserved);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Room> getReservedRooms(String id) {
        ArrayList<Room> rooms = new ArrayList<>();
        try {
            PreparedStatement preparedStatement;


                preparedStatement = connection
                        .prepareStatement("select * from room,reservation where room.rid = reservation.rid and reservation.id=?");
                // Parameters start with 1
                preparedStatement.setString(1, id);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.rid = rs.getString("rid");
                room.date = rs.getString("date");
                room.kind = rs.getString("kind");
                room.timeslot = rs.getString("timeslot");
                room.name = rs.getString("name");
                room.capacity = rs.getInt("capacity");
                room.reserved = rs.getBoolean("reserved");
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public ArrayList<Room> getRooms(String date, String kind, String timeslot, int people) {
        ArrayList<Room> rooms = new ArrayList<>();
        try {
            PreparedStatement preparedStatement;
            if (kind == null || kind.isEmpty()) {
                if (timeslot == null || timeslot.isEmpty()) {

                    preparedStatement = connection
                            .prepareStatement("select * from room where date = ? and capacity>=?");
                    // Parameters start with 1
                    preparedStatement.setString(1, date);
                    preparedStatement.setInt(2, people);
                } else {
                    preparedStatement = connection
                            .prepareStatement("select * from room where date = ? and timeslot=? and capacity>=?");
                    // Parameters start with 1
                    preparedStatement.setString(1, date);
                    preparedStatement.setString(2, timeslot);
                    preparedStatement.setInt(3, people);
                }
            }else{
                if (timeslot == null || timeslot.isEmpty()) {

                    preparedStatement = connection
                            .prepareStatement("select * from room where date = ? and kind = ? and capacity>=?");
                    // Parameters start with 1
                    preparedStatement.setString(1, date);
                    preparedStatement.setString(2, kind);
                    preparedStatement.setInt(3, people);
                } else {
                    preparedStatement = connection
                            .prepareStatement("select * from room where date = ? and kind = ? and timeslot=? and capacity>=?");
                    // Parameters start with 1
                    preparedStatement.setString(1, date);
                    preparedStatement.setString(2, kind);
                    preparedStatement.setString(3, timeslot);
                    preparedStatement.setInt(4, people);
                }
            }
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.rid = rs.getString("rid");
                room.date = rs.getString("date");
                room.kind = rs.getString("kind");
                room.timeslot = rs.getString("timeslot");
                room.name = rs.getString("name");
                room.capacity = rs.getInt("capacity");
                room.reserved = rs.getBoolean("reserved");
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public Room getSingleRoom(String name, String date, String timeslot) {
        Room room = new Room();
        try {
            PreparedStatement preparedStatement;

                preparedStatement = connection
                        .prepareStatement("select * from room where name = ? and date = ? and timeslot=?");
                // Parameters start with 1
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, date);
                preparedStatement.setString(3, timeslot);

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                room.rid = rs.getString("rid");
                room.date = rs.getString("date");
                room.kind = rs.getString("kind");
                room.timeslot = rs.getString("timeslot");
                room.name = rs.getString("name");
                room.capacity = rs.getInt("capacity");
                room.reserved = rs.getBoolean("reserved");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return room;
    }

    public boolean updateRoom(Room room){
        try {
            PreparedStatement preparedStatement;

            preparedStatement = connection
                    .prepareStatement("update room set reserved=? where name=? and date=? and timeslot=?");
            // Parameters start with 1
            preparedStatement.setBoolean(1, room.reserved);
            preparedStatement.setString(2, room.name);
            preparedStatement.setString(3, room.date);
            preparedStatement.setString(4, room.timeslot);

            int result = preparedStatement.executeUpdate();
            if (result>0)
                return true;
            else
                return false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


}