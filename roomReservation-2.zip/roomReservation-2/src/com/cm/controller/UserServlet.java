package com.cm.controller;


import com.cm.dao.RoomDao;
import com.cm.model.Room;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class UserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        RoomDao roomDao = new RoomDao();
        String id = request.getParameter("id");

        ArrayList<Room> reservedRoom = new ArrayList<>();
        reservedRoom = roomDao.getReservedRooms(id);

        request.setAttribute("reservedRoom", reservedRoom);
        request.setAttribute("id", id);
        request.getSession().setAttribute("id", id);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("user.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getSession().setAttribute("id",null);
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("user.jsp");
        requestDispatcher.forward(req, resp);
    }

}
