package com.cm.controller;

import com.cm.dao.RoomDao;
import com.cm.model.Data;
import com.cm.model.Room;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.cm.model.Data.rooms;

public class DateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");
        String kind = request.getParameter("kind");
        int people = Integer.parseInt(request.getParameter("people"));

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = df.format(new Date());

        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        calendar2.add(Calendar.DATE, 3);
        String futureDate = sdf2.format(calendar2.getTime());
        if (date.compareTo(currentDate)<0 || date.compareTo(futureDate)>0 ){
            response.setContentType("text/html;charset=utf-8");

            PrintWriter out = response.getWriter();

            out.print("<script language='javascript'>alert('Invalid date input.');window.location.href='date.jsp';</script>");
        } else
        if (people<0) {
            response.setContentType("text/html;charset=utf-8");

            PrintWriter out = response.getWriter();

            out.print("<script language='javascript'>alert('Capacity should be larger than zero.');window.location.href='date.jsp';</script>");
        }else {
            //        System.out.println(date + " " + kind + " " + timeslot + " " + people);
            if (timeslot.equals("ALL"))
                timeslot = null;
            if (kind.equals("ALL"))
                kind = null;
            ArrayList<Room> tempRoom = roomDao.getRooms(date, kind, timeslot, people);

//        Data.room
            request.setAttribute("tempRoom", tempRoom);
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("date.jsp");
            requestDispatcher.forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Room> tempRoom = new ArrayList<>();
        request.setAttribute("tempRoom", tempRoom);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("date.jsp");
        requestDispatcher.forward(request, response);
    }
}
