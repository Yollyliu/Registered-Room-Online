package com.cm.controller;

import com.cm.dao.RoomDao;
import com.cm.model.Room;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class ManageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");
        String kind = request.getParameter("kind");
        int people = Integer.parseInt(request.getParameter("people"));

        if (people<0) {
            response.setContentType("text/html;charset=utf-8");

            PrintWriter out = response.getWriter();

            out.print("<script language='javascript'>alert('Capacity should be larger than zero.');window.location.href='date.jsp';</script>");
        }else {
//        System.out.println(date + " " + kind + " " + timeslot + " " + people);
            if (timeslot.equals("ALL"))
                timeslot = null;
            if (kind.equals("ALL"))
                kind = null;
            ArrayList<Room> tempRoom = roomDao.getRooms(date, kind, timeslot, people);

            request.setAttribute("tempRoom", tempRoom);
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("admin.jsp");
            requestDispatcher.forward(request, response);
        }
    }

}
