package com.cm.controller;

import com.cm.dao.ReservationDao;
import com.cm.dao.RoomDao;
import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class RoomChosenServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        ReservationDao reservationDao = new ReservationDao();

        String name = request.getParameter("name");
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");
        String kind = request.getParameter("kind");

        User user = (User) request.getSession().getAttribute("user");
        int booked = reservationDao.getReservationNumber(user.id);
        Room room = roomDao.getSingleRoom(name, date, timeslot);
                // not reserved yet
        if (room.reserved == false) {
            // one could reserve 3 rooms at most
            if (booked < 3) {
                System.out.println("booked= "+booked);
                room.reserved = true;
                roomDao.updateRoom(room);
                Reservation reservation = new Reservation();
                reservation.id = user.id;
                reservation.rid = room.rid;
                reservationDao.addReservation(reservation);

                ArrayList<Room> reservedRoom = new ArrayList<>();

                reservedRoom = roomDao.getReservedRooms(user.id);
                for (Room room1 : reservedRoom)
                    System.out.println(room1.name+" "+room1.date+" "+room1.timeslot);

                request.setAttribute("reservedRoom", reservedRoom);
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("reserve.jsp");
                requestDispatcher.forward(request, response);
            } else {
                response.setContentType("text/html;charset=utf-8");

                PrintWriter out=response.getWriter();

                out.print("<script language='javascript'>alert('You have reserved more than 3 rooms. Reserve failed.');window.location.href='date.jsp';</script>");
            }
            // has been reserved
        } else {
            response.setContentType("text/html;charset=utf-8");

            PrintWriter out=response.getWriter();

            out.print("<script language='javascript'>alert('Room had been reserved. Reserve failed.');window.location.href='date.jsp';</script>");
        }


    }
}
