package com.cm.controller;

import com.cm.dao.UserDao;
import com.cm.model.Data;
import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class LogInServlet extends HttpServlet {

    public static Data data;

    @Override
    public void init() throws ServletException {
        super.init();
        data = new Data();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        String password = req.getParameter("pwd");
        User user = new UserDao().getUser(id, password);
        if (user==null){
            resp.setContentType("text/html;charset=utf-8");

            PrintWriter out=resp.getWriter();

            out.print("<script language='javascript'>alert('user name or password is wrong');window.location.href='index.jsp';</script>");
        }else if (user.authority==0){
            req.getSession().setAttribute("user",user);
            ArrayList<Room> tempRoom = new ArrayList<>();
            req.setAttribute("tempRoom", tempRoom);
            RequestDispatcher dispatcher = req.getRequestDispatcher("date.jsp");
            dispatcher.forward(req, resp);
        } else {
            req.getSession().setAttribute("user",user);
            ArrayList<Room> tempRoom = new ArrayList<>();
            req.setAttribute("tempRoom", tempRoom);
            RequestDispatcher dispatcher = req.getRequestDispatcher("admin.jsp");
            dispatcher.forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp");
        dispatcher.forward(req, resp);
    }
}
