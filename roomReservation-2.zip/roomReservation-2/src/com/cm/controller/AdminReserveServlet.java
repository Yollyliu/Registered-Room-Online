package com.cm.controller;

import com.cm.dao.ReservationDao;
import com.cm.dao.RoomDao;
import com.cm.dao.UserDao;
import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class AdminReserveServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        UserDao userDao = new UserDao();
        ReservationDao reservationDao = new ReservationDao();

        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");
        String admin = request.getParameter("admin");

      //  System.out.println(id + " " + name + " " + date);

        if (admin.equals("Delete")) {
            Room room = roomDao.getSingleRoom(name, date, timeslot);
            if (room.reserved == true) {
                room.reserved = false;
                roomDao.updateRoom(room);

                Reservation reservation = new Reservation();
                reservation.id = id;
                reservation.rid = room.rid;
                reservationDao.deleteReservation(reservation);

                response.setContentType("text/html;charset=utf-8");

                PrintWriter out = response.getWriter();

                out.print("<script language='javascript'>alert('Delete Successfully.');window.location.href='admin.jsp';</script>");
                // has been reserved
            } else {
                response.setContentType("text/html;charset=utf-8");

                PrintWriter out = response.getWriter();

                out.print("<script language='javascript'>alert('Room had not been reserved. Delete failed.');window.location.href='admin.jsp';</script>");
            }
        } else if (admin.equals("Reserve")) {
            Room room = roomDao.getSingleRoom(name, date, timeslot);
            User user = userDao.getUserById(id);
            if (room.reserved == false && user != null) {
                room.reserved = true;
                roomDao.updateRoom(room);
                Reservation reservation = new Reservation();
                reservation.id = id;
                reservation.rid = room.rid;
                System.out.println(reservation.id + " " + reservation.rid);

                reservationDao.addReservation(reservation);
                response.setContentType("text/html;charset=utf-8");

                PrintWriter out = response.getWriter();
                out.print("<script language='javascript'>alert('Reserve Succesfully');window.location.href='admin.jsp';</script>");
                // has been reserved
            } else {
                response.setContentType("text/html;charset=utf-8");

                PrintWriter out = response.getWriter();
                if (room.reserved == true)
                    out.print("<script language='javascript'>alert('Room had been reserved. Reserve failed.');window.location.href='admin.jsp';</script>");
                else
                    out.print("<script language='javascript'>alert('Wrong user id. Reserve failed.');window.location.href='admin.jsp';</script>");
            }
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("admin.jsp");
        requestDispatcher.forward(req, resp);
    }
}
