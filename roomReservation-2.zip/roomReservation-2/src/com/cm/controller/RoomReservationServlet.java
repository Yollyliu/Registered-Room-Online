package com.cm.controller;

import com.cm.dao.ReservationDao;
import com.cm.dao.RoomDao;
import com.cm.model.Data;
import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class RoomReservationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        ReservationDao reservationDao = new ReservationDao();
        String name = request.getParameter("name");
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");

        User user = (User)request.getSession().getAttribute("user");

        Room room = roomDao.getSingleRoom(name, date, timeslot);
        if (room.reserved == true) {
            room.reserved = false;
            roomDao.updateRoom(room);

            Reservation reservation = new Reservation();
            reservation.id = user.id;
            reservation.rid = room.rid;
//            System.out.println(reservation.id+" "+reservation.rid);

            reservationDao.deleteReservation(reservation);
//                    Data.reservations.add(reservation);
//                    new Data().setData();
//            System.out.println("ddddddddddd");
            // has been reserved
        } else {

        }

        ArrayList<Room> reservedRoom = new ArrayList<>();
        reservedRoom = roomDao.getReservedRooms(user.id);

        request.setAttribute("reservedRoom", reservedRoom);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("reserve.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();

        User user = (User)request.getSession().getAttribute("user");
        ArrayList<Room> reservedRoom = new ArrayList<>();
        reservedRoom = roomDao.getReservedRooms(user.id);

        request.setAttribute("reservedRoom", reservedRoom);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("reserve.jsp");
        requestDispatcher.forward(request, response);
    }
}
