package com.cm.controller;

import com.cm.dao.ReservationDao;
import com.cm.dao.RoomDao;
import com.cm.model.Reservation;
import com.cm.model.Room;
import com.cm.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class UserDeleteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RoomDao roomDao = new RoomDao();
        ReservationDao reservationDao = new ReservationDao();
        String name = request.getParameter("name");
        String date = request.getParameter("date");
        String timeslot = request.getParameter("timeslot");

        String id = (String)request.getSession().getAttribute("id");

        Room room = roomDao.getSingleRoom(name, date, timeslot);
        if (room.reserved == true) {
            room.reserved = false;
            roomDao.updateRoom(room);

            Reservation reservation = new Reservation();
            reservation.id = id;
            reservation.rid = room.rid;
            reservationDao.deleteReservation(reservation);
        } else {

        }

        ArrayList<Room> reservedRoom = new ArrayList<>();
        reservedRoom = roomDao.getReservedRooms(id);
        System.out.println(id);

        request.setAttribute("reservedRoom", reservedRoom);
        request.setAttribute("id",id);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("user.jsp");
        requestDispatcher.forward(request, response);
    }
}
