package com.cm.utils;

import com.cm.dao.RoomDao;
import com.cm.dao.UserDao;
import com.cm.model.Room;
import com.cm.model.User;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class DataWriter {

    public static void main(String[] args){
        ArrayList<Room> rooms = createRoom();
        newRoom(rooms);
    }

    public static void newUsers(User[] users){
        UserDao userDao = new UserDao();
        for (User user : users){
            userDao.createUser(user);
        }
    }

    public static void newRoom(ArrayList<Room> rooms){
        RoomDao roomDao = new RoomDao();
        for (Room room : rooms){
            roomDao.createRoom(room);
        }
    }

    public static ArrayList<Room> createRoom(){
        int[] lcapacity = {15, 20, 25, 20, 30};
        int[] ccapacity = {40,50,40,30,25};
        int[] tcapacity = {200,250,300,350,400};
        String[] kind = {"LAB", "CONFERENCE", "TEACHING"};
        String[] timeslot = {"08:00-10:00",
            "10:00-12:00",
            "12:00-14:00",
            "14:00-16:00",
            "16:00-18:00",
            "18:00-20:00",
            "20:00-22:00",
            "22:00-24:00"};
        String[] labName = {"201", "202", "203", "204", "205"};
        String[] cName = {"301","302","303","304","305"};
        String[] tName = {"401","402","403","404","405"};

        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");


        ArrayList<Room> rooms = new ArrayList<>();
        Random random = new Random();
        int date = (int) (new Date().getTime()/1000);
        int count = 0;
        for (int i=0; i<4; i++) {
            Date d = calendar2.getTime();
            String currentDate = sdf2.format(d);
           // System.out.println(date);
            System.out.println(currentDate);

            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < 8; k++) {
                    Room room = new Room();
                    int rid = date + count++;
                    room.rid = rid +"";
                    room.reserved = false;
                    room.timeslot = timeslot[k];
                    room.date = currentDate;
                    room.name = labName[j];
                    room.kind = "LAB";
                    room.capacity = lcapacity[j];
                    rooms.add(room);
                }
            }

            for(int j=0 ; j < 5 ; j++){
                for (int k = 0; k < 8; k++) {
                    Room room = new Room();
                    int rid = date + count++;
                    room.rid = rid +"";
                    room.reserved = false;
                    room.timeslot = timeslot[k];
                    room.date = currentDate;
                    room.name = cName[j];
                    room.kind = "CONFERENCE";
                    room.capacity = ccapacity[j];
                    rooms.add(room);
                }
            }

            for(int j=0 ; j < 5 ; j++){
                for (int k = 0; k < 8; k++) {
                    Room room = new Room();
                    int rid = date + count++;
                    room.rid = rid +"";
                    room.reserved = false;
                    room.timeslot = timeslot[k];
                    room.date = currentDate;
                    room.name = tName[j];
                    room.kind = "TEACHING";
                    room.capacity = tcapacity[j];
                    rooms.add(room);
                }
            }

            calendar2.add(Calendar.DATE, 1);
        }
        return rooms;
    }
}
