import com.cm.dao.RoomDao;
import com.cm.model.Room;
import com.cm.utils.ConnectionManager;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class RoomDaoTest {
    public RoomDao roomDao = new RoomDao();
    private Connection connection = ConnectionManager.getConnection();

    @Test
    public void getReservedRooms() throws Exception {
        String id = "youlin";
        ArrayList<Room> rooms = roomDao.getReservedRooms(id);
        int i = rooms.size();
        rooms = new ArrayList<>();
        try {
            PreparedStatement preparedStatement;


            preparedStatement = connection
                    .prepareStatement("select * from room,reservation where room.rid = reservation.rid and reservation.id=?");
            // Parameters start with 1
            preparedStatement.setString(1, id);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.rid = rs.getString("rid");
                room.date = rs.getString("date");
                room.kind = rs.getString("kind");
                room.timeslot = rs.getString("timeslot");
                room.name = rs.getString("name");
                room.capacity = rs.getInt("capacity");
                room.reserved = rs.getBoolean("reserved");
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int j = rooms.size();
        assertEquals(i, j);

    }

}
