import com.cm.dao.ReservationDao;
import com.cm.model.Reservation;
import com.cm.utils.ConnectionManager;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.*;

public class ReservationDaoTest {

    public ReservationDao reservationDao = new ReservationDao();
    private Connection connection = ConnectionManager.getConnection();
    @Test
    public void getReservationNumber() throws Exception {
        String id = "youlin";
        int number = reservationDao.getReservationNumber(id);
        int i=0;
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from reservation where id=?");
            // Parameters start with 1
            preparedStatement.setString(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        assertEquals(i, number);
    }

    @Test
    public void addReservation() throws Exception {

        Reservation reservation = new Reservation();
        reservation.id = "youlin";
        reservation.rid = "123456789";
        int i = reservationDao.getReservationNumber(reservation.id);
        reservationDao.addReservation(reservation);
        reservationDao.deleteReservation(reservation);
        int j = reservationDao.getReservationNumber(reservation.id);
        assertEquals(i, j);
    }

}
