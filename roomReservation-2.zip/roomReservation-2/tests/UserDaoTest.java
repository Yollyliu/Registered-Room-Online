import com.cm.dao.UserDao;
import com.cm.model.User;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

public class UserDaoTest {
    public UserDao userDao = new UserDao();

    @Test
    public void getUser() throws Exception {
        User user = userDao.getUser("","1234");
        assertEquals(null, user);
    }

    @Test
    public void getUserById() throws Exception {
        User user = userDao.getUserById("wanlu");
        assertEquals("wanlu",user.id);
    }


}
